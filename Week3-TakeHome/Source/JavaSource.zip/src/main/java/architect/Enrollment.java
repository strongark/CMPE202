package architect;

import java.util.Date;

/**
 * Created by tranpham on 6/28/17.
 */
public class Enrollment {

    String enrollment_id;

//    Student student;

//    Course course;

    Date enrolled_date;

    String grade;

    boolean is_paid;
}
