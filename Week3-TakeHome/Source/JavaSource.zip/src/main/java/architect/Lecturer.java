package architect;

import java.util.ArrayList;

/**
 * Created by tranpham on 6/28/17.
 */
public class Lecturer extends Person {

    String lecturer_id;

//    ArrayList<Course> courses;

    float salary;

    String salary_type;
}
