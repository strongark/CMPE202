package architect;

import java.util.Date;

/**
 * Created by tranpham on 6/28/17.
 */
public class Person {
    String first_name;
    String last_name;
    String phone;
    String email;
    String address;
    Date   date_of_birth;
    String gender;
}
